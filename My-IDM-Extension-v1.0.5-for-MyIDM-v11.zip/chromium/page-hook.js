(() => {
  const TOKEN = "idm-page-hook-v62";
  const HTTP_RE = /^https?:/i;

  const clean = (value) => {
    if (!value) return "";
    try {
      return String(value)
        .replace(/\\/g, "/")
        .split("/")
        .pop()
        .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "_")
        .trim();
    } catch (_) {
      return "";
    }
  };

  const http = (value) => {
    try {
      const u = new URL(String(value), location.href);
      return HTTP_RE.test(u.protocol) ? u.href : "";
    } catch (_) {
      return "";
    }
  };

  const emit = (type, data = {}) => {
    try {
      window.postMessage({ source: TOKEN, type, ...data }, "*");
    } catch (_) {}
  };

  const isDirectFileUrl = (url) => {
    const u = http(url);
    if (!u) return false;
    try {
      const parsed = new URL(u);
      const fileExt =
        /\.(?:exe|msi|zip|7z|rar|tar|gz|bz2|xz|pdf|dmg|pkg|deb|rpm|apk|aab|ipa|iso|img|bin|msix|msixbundle|mp3|wav|flac|aac|ogg|m4a|mp4|mkv|webm|mov|avi|m4v|ts|m3u8|mpd|csv|tsv|xlsx|xls|docx|doc|pptx|ppt|txt|rtf|json|xml)(?:$|[?#])/i.test(
          parsed.pathname,
        );
      const downloadParam =
        /(?:^|[?&])(?:download|attachment|filename|file|fileName|file_name)=/i.test(
          parsed.search,
        );
      return fileExt || downloadParam;
    } catch (_) {
      return false;
    }
  };

  // Intent only — arm the tab, do NOT treat intermediate pages as the file.
  const isDownloadIntent = (url, hint = "") => {
    const u = http(url);
    if (!u) return false;
    if (isDirectFileUrl(u)) return true;

    const text = String(hint || "").toLowerCase();
    if (
      /\b(download|save|export|installer|setup|get\s+file|windows|macos|mac\s*os|linux)\b/i.test(
        text,
      )
    ) {
      return true;
    }

    try {
      const parsed = new URL(u);
      const pathAndSearch = `${parsed.pathname} ${parsed.search}`.toLowerCase();
      if (
        /thank[-_]?you|\/download(?:\/|$)|\/downloads(?:\/|$)|\/get(?:\/|$)|\/setup|\/installer|\/release|\bdv=|build=stable|build=insider/i.test(
          pathAndSearch,
        )
      ) {
        return true;
      }
    } catch (_) {}

    return false;
  };

  const report = (href, download, hint) => {
    if (!href) return;
    if (!(download || isDownloadIntent(href, hint))) return;
    emit("idm:page-download", {
      url: href,
      fileName: clean(download),
      referrer: location.href,
      userGesture: true,
      direct: !!(download || isDirectFileUrl(href)),
    });
  };

  const originalClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      const href = http(this.href);
      const download = this.getAttribute("download") || "";
      const hint = `${download} ${this.textContent || ""} ${this.id || ""} ${this.className || ""} ${this.getAttribute("aria-label") || ""}`;
      report(href, download, hint);
    } catch (_) {}
    return originalClick.call(this);
  };

  document.addEventListener(
    "click",
    (event) => {
      try {
        const a = event.target?.closest?.("a[href]");
        if (!a) return;
        const href = http(a.href);
        if (!href) return;
        const download = a.getAttribute("download") || "";
        const hint = `${download} ${a.textContent || ""} ${a.getAttribute("aria-label") || ""} ${a.title || ""} ${a.className || ""} ${a.id || ""}`;
        report(href, download, hint);
      } catch (_) {}
    },
    true,
  );
})();
