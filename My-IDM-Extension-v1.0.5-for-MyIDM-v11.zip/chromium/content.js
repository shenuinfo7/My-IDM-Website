let lastTarget = null;
const videoPanels = new WeakMap();

/* ============================================================
   GENERAL TARGET HELPERS
   ============================================================ */

function findTarget(node) {
  let current = node instanceof Element ? node : null;
  let depth = 0;

  while (current && depth < 12) {
    const target = current.closest(
      "a[href],area[href],button,input[type='button'],input[type='submit'],summary,[role='button'],[download],video,audio,form,[data-url],[data-href],[data-download-url],[data-download],[data-file-url],[data-direct-url]",
    );
    if (target) return target;

    const root = current.getRootNode?.();
    if (root && root.host instanceof Element) {
      current = root.host;
      depth += 1;
      continue;
    }
    current = current.parentElement;
    depth += 1;
  }

  return node instanceof Element ? node : null;
}

function absoluteHttp(value) {
  if (!value) return null;

  try {
    const text = String(value)
      .trim()
      .replace(/^['"]|['"]$/g, "");

    const url = new URL(text, location.href).toString();

    return /^https?:/i.test(url) ? url : null;
  } catch (_) {
    return null;
  }
}

const URL_ATTRS = [
  "data-url",
  "data-href",
  "data-download-url",
  "data-download",
  "data-file-url",
  "data-src",
  "data-link",
  "data-target-url",
  "data-direct-url",
  "data-file",
  "data-path",
  "data-endpoint",
  "data-resource",
  "data-video-url",
  "data-source",
  "data-media-url",
];

function extractUrlFromText(value) {
  if (!value) return null;

  const text = String(value);

  const patterns = [
    /(?:window\.open|location(?:\.href)?|location\.assign|location\.replace)\s*\(\s*['"]([^'"]+)['"]/i,

    /(?:href|url|downloadUrl|download_url|fileUrl|file_url|src|source|endpoint)\s*[:=]\s*['"]([^'"]+)['"]/i,

    /(?:fetch|axios\.(?:get|post)|window\.location(?:\.href)?|location(?:\.href)?|open)\s*\(\s*['"]([^'"]+)['"]/i,

    /['"](https?:\/\/[^'"\s]+)['"]/i,
  ];

  for (const re of patterns) {
    const match = text.match(re);

    const url = absoluteHttp(match?.[1]);

    if (url) return url;
  }

  return null;
}

function targetUrl(element) {
  if (!(element instanceof Element)) return null;

  const seen = new Set();
  const candidates = [];

  const add = (node) => {
    if (!(node instanceof Element)) return;
    if (seen.has(node)) return;

    seen.add(node);
    candidates.push(node);
  };

  add(element);

  let parent = element.parentElement;

  for (let i = 0; parent && i < 6; i += 1, parent = parent.parentElement) {
    add(parent);
  }

  const buttonLike = element.matches(
    "button,input[type='button'],input[type='submit'],summary,[role='button']",
  );

  if (
    buttonLike ||
    element.hasAttribute("data-url") ||
    element.hasAttribute("data-download-url") ||
    element.hasAttribute("download")
  ) {
    const descendants =
      element.querySelectorAll?.(
        "a[href],area[href],[href],[download],[data-url],[data-href],[data-download-url],[data-download],[data-file-url],[data-direct-url],[data-src],[onclick]",
      ) || [];

    for (const node of Array.from(descendants).slice(0, 50)) {
      add(node);
    }
  }

  for (const node of candidates) {
    const anchor =
      node.closest?.("a[href],area[href]") ||
      (node.matches?.("a[href],area[href]") ? node : null);

    const direct = absoluteHttp(anchor?.getAttribute("href"));

    if (direct) return direct;

    for (const name of URL_ATTRS) {
      const url = absoluteHttp(node.getAttribute(name));

      if (url) return url;
    }

    const onclickUrl = extractUrlFromText(node.getAttribute("onclick"));

    if (onclickUrl) return onclickUrl;
  }

  const form = element.closest("form[action]");

  return absoluteHttp(form?.getAttribute("action"));
}

function fileNameFromTarget(element) {
  if (!(element instanceof Element)) return "";

  return (
    element.getAttribute("download") ||
    element.closest("[download]")?.getAttribute("download") ||
    ""
  );
}

function isFileLikeUrl(url) {
  if (!url) return false;

  try {
    const u = new URL(url, location.href);
    const path = u.pathname.toLowerCase();
    const ext =
      /\.(exe|msi|zip|7z|rar|tar|gz|bz2|xz|pdf|dmg|pkg|deb|rpm|apk|aab|ipa|iso|img|bin|msix|msixbundle|mp3|wav|flac|aac|ogg|m4a|mp4|mkv|webm|mov|avi|m4v|ts|m3u8|mpd|csv|tsv|xlsx|xls|docx|doc|pptx|ppt|txt|rtf|json|xml)(?:$|[?#])/i.test(
        path,
      );
    const downloadParam =
      /(?:^|[?&])(?:download|attachment|filename|file|fileName|file_name)=/i.test(
        u.search,
      );
    return ext || downloadParam;
  } catch (_) {
    return false;
  }
}

function isLikelyDownloadTarget(element) {
  if (!(element instanceof Element)) return false;

  const text = [
    element.textContent || "",
    element.getAttribute("aria-label") || "",
    element.getAttribute("title") || "",
    element.getAttribute("download") || "",
    element.className || "",
    element.id || "",
  ]
    .join(" ")
    .toLowerCase();

  return /download|save|installer|setup|get\s+(?:the\s+)?file|export|windows|macos|mac\s*os|linux|\.exe|\.msi|\.dmg|\.zip|\.pdf/.test(
    text,
  );
}

function hasExplicitDownloadUrl(element) {
  if (!(element instanceof Element)) return false;

  const buttonLike = element.matches(
    "button,input[type='button'],input[type='submit'],summary,[role='button']",
  );

  const urlAttrs = URL_ATTRS.some((name) => element.hasAttribute(name));

  const downloadAttr =
    element.hasAttribute("download") || !!element.closest("[download]");

  const onclick = extractUrlFromText(element.getAttribute("onclick"));

  return (
    buttonLike &&
    (urlAttrs ||
      downloadAttr ||
      !!onclick ||
      !!element.closest(
        "[data-url],[data-href],[data-download-url],[data-download],[data-file-url],[data-direct-url]",
      ))
  );
}

function shouldInterceptClick(element, url) {
  if (!(element instanceof Element) || !url) {
    return false;
  }

  if (hasExplicitDownloadUrl(element)) {
    return true;
  }

  if (element.hasAttribute("download") || element.closest("[download]")) {
    return true;
  }

  // A normal anchor whose text says "Download" may still be a navigation/help
  // page. Only explicit download attributes or a file-like URL are intercepted.
  if (isFileLikeUrl(url)) {
    return true;
  }

  const anchor = element.closest("a[href],area[href]");

  const rel = `
    ${anchor?.getAttribute("rel") || ""}
    ${anchor?.getAttribute("target") || ""}
  `.toLowerCase();

  return /download/.test(rel);
}


/* ============================================================
   PAGE-HOOK BRIDGE (MAIN world → extension)
   page-hook.js runs in page MAIN world and can only use
   window.postMessage. Relay those signals to the background.
   ============================================================ */

window.addEventListener(
  "message",
  (event) => {
    try {
      const data = event.data;
      if (!data || typeof data !== "object") return;
      if (typeof data.source !== "string" || !data.source.startsWith("idm-page-hook")) return;

      if (data.type === "idm:page-download" && data.url) {
        chrome.runtime
          .sendMessage({
            type: "idm:page-download",
            url: data.url,
            fileName: data.fileName || "",
            referrer: data.referrer || location.href,
            direct: !!data.direct,
            userGesture: !!data.userGesture,
          })
          .catch(() => {});
        return;
      }

      if (data.type === "idm:page-request" && data.url) {
        chrome.runtime
          .sendMessage({
            type: "idm:page-request",
            url: data.url,
            fileName: data.fileName || "",
            referrer: data.referrer || location.href,
          })
          .catch(() => {});
      }
    } catch (_) {}
  },
  true,
);

function armDynamic(element, mode, force = false) {
  if (!force && !isLikelyDownloadTarget(element)) return;

  chrome.runtime
    .sendMessage({
      type: "idm:arm-dynamic-click",
      mode,
    })
    .catch(() => {});
}

function markUserGesture() {
  chrome.runtime.sendMessage({ type: "idm:user-gesture" }).catch(() => {});
}

document.addEventListener(
  "pointerdown",
  (event) => {
    if (event.button === 0) markUserGesture();
  },
  true,
);

document.addEventListener(
  "keydown",
  (event) => {
    if (event.key === "Enter" || event.key === " ") markUserGesture();
  },
  true,
);

/* ============================================================
   CONTEXT MENU
   ============================================================ */

document.addEventListener(
  "contextmenu",
  (event) => {
    lastTarget = findTarget(event.target);
  },
  true,
);

/* ============================================================
   DYNAMIC DOWNLOAD DETECTION
   ============================================================ */

document.addEventListener(
  "pointerdown",
  (event) => {
    if (event.button !== 0) return;

    const target = findTarget(event.target);

    if (!target) return;

    const url = targetUrl(target);

    if (
      !url &&
      isLikelyDownloadTarget(target) &&
      target.matches(
        "button,input[type='button'],input[type='submit'],summary,[role='button']",
      )
    ) {
      armDynamic(target, "pointerdown-dynamic");
    }
  },
  true,
);

document.addEventListener(
  "mousedown",
  (event) => {
    if (event.button !== 0) return;

    const target = findTarget(event.target);

    if (!target) return;

    const url = targetUrl(target);

    if (
      !url &&
      isLikelyDownloadTarget(target) &&
      target.matches(
        "button,input[type='button'],input[type='submit'],summary,[role='button']",
      )
    ) {
      armDynamic(target, "mousedown-dynamic");
    }
  },
  true,
);

/* ============================================================
   NORMAL DOWNLOAD CLICK
   ============================================================ */

document.addEventListener(
  "click",
  (event) => {
    if (event.defaultPrevented || event.button !== 0) {
      return;
    }

    const target = findTarget(event.target);

    if (!target) return;

    const url = targetUrl(target);

    // Arm the tab for every real HTTP link click. We do NOT cancel ordinary
    // navigation. If Chrome creates a DownloadItem afterwards, background
    // hands it to My IDM. This covers signed URLs, thank-you redirects,
    // extensionless CDN links and JS-generated downloads.
    const anchor = target.closest?.("a[href],area[href]");
    const anchorUrl = absoluteHttp(anchor?.getAttribute("href") || anchor?.href || "");
    if (anchorUrl) {
      chrome.runtime
        .sendMessage({ type: "idm:arm-dynamic-click", mode: "any-link-click" })
        .catch(() => {});
    }

    // Known direct file links: hand to IDM immediately and stop Chrome.
    if (url && shouldInterceptClick(target, url)) {
      event.preventDefault();
      event.stopImmediatePropagation();

      chrome.runtime
        .sendMessage({
          type: "idm:click-url",
          url,
          fileName: fileNameFromTarget(target),
          referrer: location.href,
          pageTitle: document.title || "",
        })
        .catch(() => {});

      return;
    }

    // Download-looking buttons or anchors (Windows / Download / Export…)
    if (isLikelyDownloadTarget(target)) {
      armDynamic(target, "click-dynamic", true);
    }
  },
  true,
);

/* ============================================================
   VIDEO HELPERS
   ============================================================ */

function isVideoElement(node) {
  return node instanceof HTMLVideoElement;
}

function bestVideoUrl(video) {
  if (!isVideoElement(video)) {
    return null;
  }

  const src = absoluteHttp(video.currentSrc || video.src || "");

  if (src) return src;

  const source = video.querySelector("source[src]");

  return absoluteHttp(source?.getAttribute("src") || "");
}

function isYouTubePage() {
  return /(^|\.)youtube\.com$|(^|\.)youtu\.be$|(^|\.)youtube-nocookie\.com$/i.test(
    location.hostname,
  );
}

function canonicalYouTubePageUrl() {
  try {
    if (!isYouTubePage()) {
      return location.href;
    }

    const u = new URL(location.href);

    const v = u.searchParams.get("v");

    if (v) {
      return `https://www.youtube.com/watch?v=${encodeURIComponent(v)}`;
    }

    return location.href;
  } catch (_) {
    return location.href;
  }
}

function videoDownloadPayload(video) {
  const mediaUrl = bestVideoUrl(video);

  const pageUrl = isYouTubePage() ? canonicalYouTubePageUrl() : location.href;

  const isDirectMedia =
    mediaUrl &&
    /\.(mp4|webm|mkv|mov|avi|m4v|ts|m3u8|mpd)(?:$|[?#])/i.test(mediaUrl);

  const url = isYouTubePage()
    ? pageUrl
    : mediaUrl && isDirectMedia
      ? mediaUrl
      : pageUrl;

  return {
    url,
    mediaUrl: mediaUrl || "",
    pageUrl,
    genericVideo: !isYouTubePage(),
    referrer: pageUrl,
    title: document.title || "Video",
  };
}

function formatSize(bytes) {
  const n = Number(bytes) || 0;

  if (!n) {
    return "Size unknown";
  }

  if (n >= 1024 ** 3) {
    return `${(n / 1024 ** 3).toFixed(1)} GB`;
  }

  if (n >= 1024 ** 2) {
    return `${(n / 1024 ** 2).toFixed(1)} MB`;
  }

  if (n >= 1024) {
    return `${(n / 1024).toFixed(0)} KB`;
  }

  return `${n} B`;
}

function safeVideoFileName(title, audioOnly = false) {
  const base =
    String(title || "Video")
      .replace(/[\\/:*?"<>|]/g, "_")
      .trim() || "Video";

  return `${base}${audioOnly ? ".mp3" : ".mp4"}`;
}

/* ============================================================
   VIDEO INFO REQUEST
   ============================================================ */

function requestVideoOptions(payload, callback) {
  const requestId = `video-${Date.now()}-${Math.random()
    .toString(36)
    .slice(2, 9)}`;

  let finished = false;
  let retried = false;

  const cleanup = () => {
    chrome.runtime.onMessage.removeListener(listener);
  };

  const finish = (info) => {
    if (finished) return;

    finished = true;

    cleanup();

    callback(info);
  };

  const listener = (message) => {
    if (
      message?.type !== "idm:video-options-result" ||
      message.requestId !== requestId
    ) {
      return;
    }

    finish(
      message.info || {
        success: false,
        error: "No response from IDM",
      },
    );
  };

  chrome.runtime.onMessage.addListener(listener);

  const send = () => {
    chrome.runtime
      .sendMessage({
        type: "idm:video-options",
        requestId,
        ...payload,
        retry: retried,
      })
      .catch(() => {
        finish({
          success: false,
          error: "IDM desktop manager is not running",
        });
      });
  };

  send();

  setTimeout(() => {
    if (finished) return;

    if (!retried) {
      retried = true;
      send();
      return;
    }

    finish({
      success: false,
      error:
        "YouTube information is taking too long. Please start the video, wait a few seconds, and click Download video again.",
    });
  }, 60000);
}

/* ============================================================
   YOUTUBE CACHE
   ============================================================ */

const videoInfoCache = new Map();
const videoInfoPending = new Map();

function prefetchVideoOptions(payload) {
  if (!payload?.url || !isYouTubePage()) {
    return;
  }

  const key = canonicalYouTubePageUrl();

  if (videoInfoCache.has(key) || videoInfoPending.has(key)) {
    return;
  }

  videoInfoPending.set(key, true);

  requestVideoOptions(payload, (info) => {
    videoInfoPending.delete(key);

    if (info?.success) {
      videoInfoCache.set(key, info);
    }
  });
}

function prefetchCurrentYouTubePage() {
  if (!isYouTubePage()) {
    return;
  }

  const url = canonicalYouTubePageUrl();

  prefetchVideoOptions({
    url,
    pageUrl: location.href,
    referrer: location.href,
    title: document.title || "YouTube video",
  });
}

prefetchCurrentYouTubePage();

document.addEventListener(
  "yt-navigate-finish",
  () => {
    setTimeout(prefetchCurrentYouTubePage, 150);
    setTimeout(prefetchCurrentYouTubePage, 1200);
  },
  true,
);

window.addEventListener(
  "popstate",
  () => setTimeout(prefetchCurrentYouTubePage, 200),
  true,
);

/* ============================================================
   VIDEO PANEL
   ============================================================ */

function createVideoPanel(video) {
  if (!isVideoElement(video) || video.dataset.idmPanelAttached === "1") {
    return;
  }

  video.dataset.idmPanelAttached = "1";

  const parent = video.parentElement;

  if (!parent) return;

  /* ==========================================================
     HOST
     ========================================================== */

  const host = document.createElement("div");

  host.className = "idm-video-host";

  host.style.cssText = `
    position:fixed!important;
    z-index:2147483647!important;
    display:block!important;
    width:0!important;
    height:0!important;
    overflow:visible!important;
    pointer-events:none!important;
    left:0!important;
    top:0!important;
  `;

  (document.fullscreenElement || document.body || parent).appendChild(host);

  /* ==========================================================
     SHADOW DOM
     ========================================================== */

  const shadow = host.attachShadow({
    mode: "open",
  });

  /* ==========================================================
     IDM STYLE
     ========================================================== */

  const style = document.createElement("style");

  style.textContent = `

    * {
      box-sizing: border-box;
    }

    :host {
      all: initial;
    }

    /* ========================================================
       MAIN WRAPPER
       ======================================================== */

    .wrap {
      position: absolute;

      top: 0;
      right: 0;

      width: 229px;

      display: flex;
      flex-direction: column;
      align-items: flex-end;

      font-family:
        Arial,
        Helvetica,
        sans-serif;

      pointer-events: none;

      opacity: 0;

      transform:
        translateY(-4px);

      transform-origin:
        top right;

      transition:
        opacity .16s ease,
        transform .16s ease;
    }

    .wrap.visible {
      opacity: 1;

      transform:
        translateY(0);
    }

    /* ========================================================
       IDM OUTER BAR
       EXACT SIZE: 229px x 25px
       ======================================================== */

    .bar {
      width: 229px;
      height: 25px;

      min-width: 229px;
      max-width: 229px;

      min-height: 25px;
      max-height: 25px;

      display: flex;
      align-items: center;

      margin: 0;
      padding: 0;

      overflow: hidden;

      background:
        linear-gradient(
          to bottom,
          #ffffff 0%,
          #f5f5f5 42%,
          #dcdcdc 100%
        );

      border:
        1px solid #737373;

      border-radius:
        3px;

      box-shadow:
        inset 0 1px 0
          rgba(255,255,255,.95),

        inset 0 -1px 0
          rgba(0,0,0,.16),

        0 1px 2px
          rgba(0,0,0,.45);

      pointer-events:
        auto;

      white-space:
        nowrap;
    }

    /* ========================================================
       LEFT ICON AREA
       ======================================================== */
       /* My IDM logo: compact and centered inside the 25px bar */
       .my-idm-logo-container {
         display: inline-flex !important;
         align-items: center !important;
         justify-content: center !important;
         flex: 0 0 24px !important;
         width: 24px !important;
         min-width: 24px !important;
         height: 23px !important;
         min-height: 23px !important;
         margin: 0 4px 0 2px !important;
         padding: 0 !important;
         overflow: hidden !important;
         line-height: 0 !important;
       }

       .my-idm-logo {
         display: block !important;
         width: 20px !important;
         height: 20px !important;
         min-width: 20px !important;
         min-height: 20px !important;
         max-width: 20px !important;
         max-height: 20px !important;
         object-fit: contain !important;
         object-position: center !important;
         visibility: visible !important;
         opacity: 1 !important;
         border: 0 !important;
         outline: 0 !important;
         box-shadow: none !important;
         background: transparent !important;
         padding: 0 !important;
         margin: 0 !important;
         flex: 0 0 20px !important;
       }

    .download {
      position: relative;

      flex: 1;

      width: auto;

      height: 23px;

      min-width: 0;
      min-height: 23px;

      display: flex;

      align-items: center;

      justify-content: flex-start;

      margin: 0;

      padding:
        0 6px;

      border:
        0;

      border-radius:
        0;

      background:
        transparent;

      color:
        #202020;

      font-family:
        Arial,
        Helvetica,
        sans-serif;

      font-size:
        11px;

      font-weight:
        bold;

      line-height:
        23px;

      text-align:
        left;

      white-space:
        nowrap;

      overflow:
        hidden;

      text-overflow:
        ellipsis;

      text-shadow:
        0 1px 0 #ffffff;

      cursor:
        pointer !important;

      outline:
        none !important;

      appearance:
        none;

      -webkit-appearance:
        none;

      transition:
        color .12s ease,
        background .12s ease;
    }

    /* ========================================================
       MAIN BUTTON HOVER
       ======================================================== */

    .download:hover {
      color:
        #ff0000 !important;

      background:
        linear-gradient(
          to bottom,
          rgba(255,255,255,.75),
          rgba(220,220,220,.45)
        );
    }

    .download:active {
      color:
        #c40000 !important;

      background:
        linear-gradient(
          to bottom,
          rgba(190,190,190,.65),
          rgba(245,245,245,.55)
        );
    }

    .download:focus {
      outline:
        none !important;
    }

    .download:disabled {
      opacity: .7;
      cursor: default !important;
    }

    /* ========================================================
       BRAND / STATUS
       ======================================================== */

    .brand {
      display: none !important;
    }

    .status {
      display: none !important;
    }

    /* ========================================================
       RIGHT CLOSE BUTTON
       ======================================================== */

    .bar-close {
      width: 23px;
      height: 23px;

      min-width: 23px;

      display: flex;

      align-items: center;
      justify-content: center;

      margin: 0;
      padding: 0;

      border:
        0;

      border-left:
        1px solid #9a9a9a;

      border-radius:
        0;

      background:
        linear-gradient(
          to bottom,
          #eeeeee 0%,
          #d4d4d4 100%
        );

      color:
        #444;

      font-family:
        Arial,
        Helvetica,
        sans-serif;

      font-size:
        16px;

      font-weight:
        normal;

      line-height:
        21px;

      cursor:
        pointer !important;

      outline:
        none !important;

      text-shadow:
        0 1px 0 #ffffff;

      appearance:
        none;

      -webkit-appearance:
        none;

      transition:
        color .12s ease,
        background .12s ease;
    }

    .bar-close:hover {
      color:
        #ff0000;

      background:
        linear-gradient(
          to bottom,
          #ffffff,
          #cfcfcf
        );
    }

    .bar-close:active {
      color:
        #a90000;

      background:
        linear-gradient(
          to bottom,
          #c9c9c9,
          #ededed
        );
    }

    /* ========================================================
       POPUP
       ======================================================== */

    .popup {
      width:
        520px;

      max-height:
        330px;

      overflow:
        auto;

      padding:
        8px;

      margin-top:
        5px;

      border:
        1px solid
        rgba(255,255,255,.15);

      border-radius:
        9px;

      background:
        rgba(18,20,24,.99);

      box-shadow:
        0 12px 35px
        rgba(0,0,0,.58);

      display:
        none;

      pointer-events:
        auto;
    }

    .popup.open {
      display:
        block;
    }

    /* ========================================================
       POPUP HEADER
       ======================================================== */

    .head {
      display:
        flex;

      align-items:
        center;

      gap:
        8px;

      padding:
        3px 3px 8px;

      border-bottom:
        1px solid
        rgba(255,255,255,.1);

      margin-bottom:
        6px;
    }

    .thumb {
      width:
        54px;

      height:
        34px;

      object-fit:
        cover;

      border-radius:
        4px;

      background:
        #303238;

      flex:
        none;
    }

    .title {
      min-width:
        0;

      flex:
        1;

      font-size:
        11px;

      font-weight:
        700;

      white-space:
        nowrap;

      overflow:
        hidden;

      text-overflow:
        ellipsis;

      color:
        #ffffff;
    }

    .sub {
      font-size:
        9px;

      opacity:
        .6;

      margin-top:
        2px;

      color:
        #ffffff;
    }

    .close {
      width:
        22px;

      height:
        22px;

      border:
        0;

      background:
        transparent;

      color:
        #bbb;

      font-size:
        17px;

      line-height:
        20px;

      cursor:
        pointer !important;

      padding:
        0;
    }

    .close:hover {
      color:
        #fff;
    }

    /* ========================================================
       QUALITY OPTIONS
       ======================================================== */

    .option {
      width:
        100%;

      min-height:
        34px;

      display:
        grid;

      grid-template-columns:
        minmax(145px,2fr)
        72px
        42px
        68px
        48px;

      align-items:
        center;

      gap:
        6px;

      padding:
        5px 6px;

      margin:
        3px 0;

      border:
        1px solid
        rgba(255,255,255,.08);

      border-radius:
        6px;

      background:
        rgba(255,255,255,.04);

      color:
        #fff;

      text-align:
        left;

      cursor:
        pointer !important;

      font-family:
        Arial,
        sans-serif;

      transition:
        background .12s ease,
        border-color .12s ease;
    }

    .option:hover {
      background:
        rgba(37,99,235,.24);

      border-color:
        rgba(96,165,250,.55);
    }

    .row-name {
      min-width:
        0;

      font-size:
        10px;

      font-weight:
        700;

      white-space:
        nowrap;

      overflow:
        hidden;

      text-overflow:
        ellipsis;
    }

    .row-size {
      font-size:
        9px;

      opacity:
        .75;

      white-space:
        nowrap;
    }

    .row-quality {
      font-size:
        10px;

      font-weight:
        800;

      white-space:
        nowrap;
    }

    .quality.hd {
      color:
        #60a5fa;
    }

    .kind {
      font-size:
        9px;

      opacity:
        .7;

      text-align:
        center;
    }

    .loading,
    .error {
      padding:
        14px 7px;

      font-size:
        10px;

      line-height:
        1.45;

      color:
        #ffffff;
    }

    .error {
      color:
        #ff9999;
    }
  `;

  shadow.appendChild(style);

  /* ==========================================================
     ELEMENTS
     ========================================================== */

  const wrap = document.createElement("div");
  wrap.className = "wrap";

  const bar = document.createElement("div");
  bar.className = "bar";

  /* LEFT ICON */

  // My IDM logo (lightweight extension icon)
  const arrow = document.createElement("span");
  arrow.className = "my-idm-logo-container";
  arrow.setAttribute("aria-hidden", "true");

  const arrowIcon = document.createElement("img");
  arrowIcon.className = "my-idm-logo";
  arrowIcon.alt = "";
  arrowIcon.draggable = false;
  arrowIcon.src = chrome.runtime.getURL("icons/icon48.png");
  arrowIcon.addEventListener("error", () => {
    // Remove a missing icon quietly to avoid repeated console errors.
    arrowIcon.remove();
  }, { once: true });

  arrow.appendChild(arrowIcon);

  /* MAIN BUTTON */

  const button = document.createElement("button");

  button.type = "button";

  button.className = "download";

  button.textContent = "My Internet Download Manager";

  button.title = "My Internet Download Manager";

  /* RIGHT SIDE LABEL REMOVED */

  const brand = document.createElement("span");

  brand.className = "brand";

  brand.textContent = "";

  /* CLOSE */

  const closeBar = document.createElement("button");

  closeBar.className = "bar-close";

  closeBar.type = "button";

  closeBar.textContent = "×";

  closeBar.title = "Hide";

  /* STATUS */

  const status = document.createElement("span");

  status.className = "status";

  /*
    IMPORTANT:
    brand is kept for compatibility,
    but CSS hides it completely.
  */

  bar.append(arrow, button, brand, closeBar, status);

  /* ==========================================================
     POPUP
     ========================================================== */

  const popup = document.createElement("div");

  popup.className = "popup";

  wrap.append(bar, popup);

  shadow.appendChild(wrap);

  /* ==========================================================
     STATE
     ========================================================== */

  let popupOpen = false;
  let busy = false;
  let hiddenByUser = false;
  let hideTimer = null;
  let currentPayload = null;
  let lastInfo = null;

  /* ==========================================================
     CLOSE POPUP
     ========================================================== */

  const closePopup = () => {
    popupOpen = false;
    popup.classList.remove("open");
  };

  /* ==========================================================
     SHOW / HIDE
     ========================================================== */

  const showBar = () => {
    if (hiddenByUser) return;

    clearTimeout(hideTimer);

    wrap.classList.add("visible");
  };

  const hideBarSoon = () => {
    if (popupOpen || hiddenByUser) {
      return;
    }

    clearTimeout(hideTimer);

    hideTimer = setTimeout(() => {
      if (!popupOpen && !hiddenByUser) {
        wrap.classList.remove("visible");
      }
    }, 450);
  };

  /* ==========================================================
     CLOSE BUTTON
     ========================================================== */

  closeBar.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();

    hiddenByUser = true;

    closePopup();

    wrap.classList.remove("visible");
  });

  /* ==========================================================
     VIDEO HOVER
     ========================================================== */

  video.addEventListener("mouseenter", showBar, true);

  video.addEventListener("mouseleave", hideBarSoon, true);

  wrap.addEventListener("mouseenter", showBar, true);

  wrap.addEventListener("mouseleave", hideBarSoon, true);

  /* ==========================================================
     ERROR
     ========================================================== */

  const showError = (message) => {
    popup.innerHTML = "";

    const error = document.createElement("div");

    error.className = "error";

    error.textContent = message;

    popup.appendChild(error);
  };

  const requestMediaCandidates = (callback) => {
    const requestId = `media-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    let done = false;
    const listener = (message) => {
      if (
        message?.type !== "idm:video-candidates-result" ||
        message.requestId !== requestId
      )
        return;
      done = true;
      chrome.runtime.onMessage.removeListener(listener);
      callback(Array.isArray(message.candidates) ? message.candidates : []);
    };
    chrome.runtime.onMessage.addListener(listener);
    chrome.runtime
      .sendMessage({ type: "idm:video-candidates", requestId })
      .catch(() => {
        if (done) return;
        done = true;
        chrome.runtime.onMessage.removeListener(listener);
        callback([]);
      });
    setTimeout(() => {
      if (done) return;
      done = true;
      chrome.runtime.onMessage.removeListener(listener);
      callback([]);
    }, 2500);
  };

  const isStreamUrl = (url, contentType = "") =>
    /\.(?:mp4|webm|mov|m4v|mkv|m3u8|mpd|m4s|ts)(?:[?#]|$)/i.test(
      String(url || ""),
    ) ||
    /video\//i.test(contentType) ||
    /mpegurl|dash\+xml/i.test(contentType);

  /* ==========================================================
     SEND DOWNLOAD
     ========================================================== */

  const sendChoice = (choice, payload, title) => {
    if (busy) return;

    busy = true;

    button.disabled = true;

    status.textContent = "Sending…";

    const requestId = `download-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 8)}`;

    const listener = (message) => {
      if (
        message?.type !== "idm:video-download-result" ||
        message.requestId !== requestId
      ) {
        return;
      }

      chrome.runtime.onMessage.removeListener(listener);

      busy = false;

      button.disabled = false;

      if (message.success) {
        status.textContent = "Sent";

        closePopup();

        setTimeout(() => {
          status.textContent = "";
        }, 1800);
      } else {
        status.textContent = "Unavailable";

        showError(
          message.error || "Could not send the video to My Download Manager.",
        );
      }
    };

    chrome.runtime.onMessage.addListener(listener);

    chrome.runtime
      .sendMessage({
        type: "idm:video-download",

        requestId,

        url:
          payload.genericVideo && (choice.ytdlp || payload.ytdlp)
            ? payload.pageUrl || location.href
            : payload.url,

        finalUrl:
          payload.genericVideo && (choice.ytdlp || payload.ytdlp)
            ? payload.pageUrl || location.href
            : payload.url,

        fileName: safeVideoFileName(title, Boolean(choice.audioOnly)),

        referrer: payload.referrer || payload.pageUrl || location.href,

        youtubeFormat: choice.format || "",

        youtubeAudioOnly: Boolean(choice.audioOnly),
        ytdlp: Boolean(choice.ytdlp || payload.ytdlp),
        mediaUrl: choice.mediaUrl || payload.mediaUrl || "",
      })
      .catch(() => {
        chrome.runtime.onMessage.removeListener(listener);

        busy = false;

        button.disabled = false;

        status.textContent = "Unavailable";

        showError("My Download Manager is not running.");
      });

    setTimeout(() => {
      chrome.runtime.onMessage.removeListener(listener);

      if (busy) {
        busy = false;

        button.disabled = false;

        status.textContent = "Unavailable";
      }
    }, 15000);
  };

  /* ==========================================================
     RENDER VIDEO OPTIONS
     ========================================================== */

  const renderOptions = (info, payload) => {
    lastInfo = info;

    const title = info?.title || payload.title || "Video";

    popup.innerHTML = "";

    const head = document.createElement("div");

    head.className = "head";

    if (info?.thumbnail) {
      const img = document.createElement("img");

      img.className = "thumb";

      img.src = info.thumbnail;

      img.alt = "";

      head.appendChild(img);
    }

    const titleBox = document.createElement("div");

    titleBox.style.minWidth = "0";

    titleBox.style.flex = "1";

    const titleEl = document.createElement("div");

    titleEl.className = "title";

    titleEl.textContent = title;

    const sub = document.createElement("div");

    sub.className = "sub";

    sub.textContent = "Name · Size · Format · Quality";

    titleBox.append(titleEl, sub);

    const close = document.createElement("button");

    close.className = "close";

    close.type = "button";

    close.textContent = "×";

    close.title = "Close";

    close.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      closePopup();
    });

    head.append(titleBox, close);

    popup.appendChild(head);

    const options = Array.isArray(info?.videoOptions) ? info.videoOptions : [];

    for (const option of options) {
      const row = document.createElement("button");

      row.type = "button";

      row.className = "option";

      row.title =
        `${title} · ${option.height || "Auto"}p · ` +
        `${formatSize(option.size)} · MP4`;

      const name = document.createElement("div");

      name.className = "row-name";

      name.textContent = title;

      const size = document.createElement("div");

      size.className = "row-size";

      size.textContent = formatSize(option.size);

      const fmt = document.createElement("div");

      fmt.className = "kind";

      fmt.textContent = "MP4";

      const q = document.createElement("div");

      q.className = `row-quality ${
        Number(option.height) >= 720 ? "quality hd" : ""
      }`;

      q.textContent = `${option.height || "Auto"}p`;

      const hd = document.createElement("div");

      hd.className = "kind";

      hd.textContent = Number(option.height) >= 720 ? "HD" : "";

      row.append(name, size, fmt, q, hd);

      row.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();

        sendChoice(
          {
            format: option.format,
          },
          payload,
          title,
        );
      });

      popup.appendChild(row);
    }

    /* ========================================================
       AUDIO
       ======================================================== */

    if (info?.audioOption) {
      const audio = info.audioOption;

      const row = document.createElement("button");

      row.type = "button";

      row.className = "option";

      row.title = `${title} · ${formatSize(audio.size)} · MP3`;

      const name = document.createElement("div");

      name.className = "row-name";

      name.textContent = title;

      const size = document.createElement("div");

      size.className = "row-size";

      size.textContent = formatSize(audio.size);

      const fmt = document.createElement("div");

      fmt.className = "kind";

      fmt.textContent = "MP3";

      const q = document.createElement("div");

      q.className = "row-quality";

      q.textContent = audio.bitrate ? `${audio.bitrate} kbps` : "Audio";

      const type = document.createElement("div");

      type.className = "kind";

      type.textContent = "Audio";

      row.append(name, size, fmt, q, type);

      row.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();

        sendChoice(
          {
            audioOnly: true,
          },
          payload,
          title,
        );
      });

      popup.appendChild(row);
    }

    if (!options.length && !info?.audioOption) {
      showError("No downloadable video stream was found.");
    }
  };

  /* ==========================================================
     YOUTUBE FALLBACK
     ========================================================== */

  const renderFallbackYouTubeOptions = (payload) => {
    const title =
      document.title.replace(/\s*[-|]\s*YouTube\s*$/i, "").trim() ||
      "YouTube video";

    popup.innerHTML = "";

    const note = document.createElement("div");

    note.className = "sub";

    note.style.cssText = "padding:4px 5px 7px;opacity:.85";

    note.textContent = "Name · Size · Format · Quality";

    popup.appendChild(note);

    for (const h of [1080, 720, 480, 360]) {
      const row = document.createElement("button");

      row.type = "button";

      row.className = "option";

      row.title = `${title} · ${h}p · MP4`;

      const name = document.createElement("div");

      name.className = "row-name";

      name.textContent = title;

      const size = document.createElement("div");

      size.className = "row-size";

      size.textContent = "Auto size";

      const format = document.createElement("div");

      format.className = "kind";

      format.textContent = "MP4";

      const quality = document.createElement("div");

      quality.className = `row-quality ${h >= 720 ? "quality hd" : ""}`;

      quality.textContent = `${h}p`;

      const hd = document.createElement("div");

      hd.className = "kind";

      hd.textContent = h >= 720 ? "HD" : "";

      row.append(name, size, format, quality, hd);

      row.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();

        sendChoice(
          {
            format:
              `bv*[height<=${h}][ext=mp4]+ba[ext=m4a]/` +
              `bv*[height<=${h}]+ba/` +
              `b[height<=${h}]`,
          },
          payload,
          title,
        );
      });

      popup.appendChild(row);
    }

    /* ========================================================
       MP3
       ======================================================== */

    const mp3 = document.createElement("button");

    mp3.type = "button";

    mp3.className = "option";

    mp3.title = `${title} · MP3`;

    const mp3Name = document.createElement("div");

    mp3Name.className = "row-name";

    mp3Name.textContent = title;

    const mp3Size = document.createElement("div");

    mp3Size.className = "row-size";

    mp3Size.textContent = "Auto size";

    const mp3Format = document.createElement("div");

    mp3Format.className = "kind";

    mp3Format.textContent = "MP3";

    const mp3Quality = document.createElement("div");

    mp3Quality.className = "row-quality";

    mp3Quality.textContent = "Audio";

    const mp3Type = document.createElement("div");

    mp3Type.className = "kind";

    mp3Type.textContent = "MP3";

    mp3.append(mp3Name, mp3Size, mp3Format, mp3Quality, mp3Type);

    mp3.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      sendChoice(
        {
          audioOnly: true,
        },
        payload,
        title,
      );
    });

    popup.appendChild(mp3);
  };

  /* ==========================================================
     MAIN IDM BUTTON CLICK
     ========================================================== */

  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();

    if (busy) return;

    if (popupOpen) {
      closePopup();
      return;
    }

    popupOpen = true;

    popup.classList.add("open");

    currentPayload = videoDownloadPayload(video);

    if (isYouTubePage()) {
      currentPayload.url = canonicalYouTubePageUrl();
    }

    if (!currentPayload.url) {
      showError(
        "This video URL is not available yet. Start the video and try again.",
      );

      return;
    }

    /* ======================================================
         YOUTUBE
         ====================================================== */

    if (isYouTubePage()) {
      const cached = videoInfoCache.get(currentPayload.url);

      if (cached?.success) {
        renderOptions(cached, currentPayload);
      } else {
        renderFallbackYouTubeOptions(currentPayload);

        if (!videoInfoPending.has(currentPayload.url)) {
          prefetchVideoOptions(currentPayload);
        }

        const waitForInfo = setInterval(() => {
          if (!popupOpen) {
            clearInterval(waitForInfo);

            return;
          }

          const ready = videoInfoCache.get(currentPayload.url);

          if (ready?.success) {
            clearInterval(waitForInfo);

            renderOptions(ready, currentPayload);
          }
        }, 250);

        setTimeout(() => clearInterval(waitForInfo), 60000);
      }
    } else {
      /* ====================================================
           NORMAL HTML5 VIDEO
           ==================================================== */

      popup.innerHTML = "";

      const loading = document.createElement("div");

      loading.className = "loading";

      loading.textContent = "Finding video stream…";

      popup.appendChild(loading);

      requestMediaCandidates((candidates) => {
        if (!popupOpen) return;

        const usable = candidates.filter((item) =>
          isStreamUrl(item?.url, item?.contentType),
        );
        // Prefer manifests over individual fragmented media chunks. Facebook and
        // other MSE players often expose .m4s/.mp4 fragments; saving one fragment
        // as an .mp4 produces a file that is not independently playable.
        const manifests = usable.filter(
          (item) =>
            /\.(?:m3u8|mpd)(?:[?#]|$)/i.test(String(item?.url || "")) ||
            /mpegurl|dash\+xml/i.test(String(item?.contentType || "")),
        );
        const best = manifests[0] || null;

        if (best) {
          popup.innerHTML = "";
          const row = document.createElement("button");
          row.type = "button";
          row.className = "option";
          row.title = `${currentPayload.title || "Video"} · Captured browser stream`;

          const name = document.createElement("div");
          name.className = "row-name";
          name.textContent = currentPayload.title || "Video";
          const size = document.createElement("div");
          size.className = "row-size";
          size.textContent = "Browser stream";
          const fmt = document.createElement("div");
          fmt.className = "kind";
          fmt.textContent = /m3u8|mpegurl/i.test(best.url + best.contentType)
            ? "HLS"
            : /mpd|dash/i.test(best.url + best.contentType)
              ? "DASH"
              : "MP4";
          const q = document.createElement("div");
          q.className = "row-quality quality hd";
          q.textContent = "Auto";
          const hd = document.createElement("div");
          hd.className = "kind";
          hd.textContent = "Video";
          row.append(name, size, fmt, q, hd);
          row.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            // Give yt-dlp the original page URL for social extractors. The captured
            // manifest is supplied separately as a fallback source. This avoids
            // treating a browser fragment as the finished MP4 file.
            sendChoice(
              { ytdlp: true, mediaUrl: best.url },
              {
                ...currentPayload,
                url: currentPayload.pageUrl || location.href,
                mediaUrl: best.url,
                ytdlp: true,
              },
              currentPayload.title || "Video",
            );
          });
          popup.appendChild(row);
          return;
        }

        // Some social sites expose no single media URL in the page. Let yt-dlp
        // inspect the page itself, while forwarding browser headers/cookies.
        popup.innerHTML = "";
        const row = document.createElement("button");
        row.type = "button";
        row.className = "option";
        row.title = "Let My IDM extract the playable video";
        const name = document.createElement("div");
        name.className = "row-name";
        name.textContent = currentPayload.title || "Video";
        const size = document.createElement("div");
        size.className = "row-size";
        size.textContent = "Auto";
        const fmt = document.createElement("div");
        fmt.className = "kind";
        fmt.textContent = "MP4";
        const q = document.createElement("div");
        q.className = "row-quality quality hd";
        q.textContent = "Best";
        const hd = document.createElement("div");
        hd.className = "kind";
        hd.textContent = "Video";
        row.append(name, size, fmt, q, hd);
        row.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          sendChoice(
            { ytdlp: true },
            { ...currentPayload, ytdlp: true },
            currentPayload.title || "Video",
          );
        });
        popup.appendChild(row);
      });
    }
  });

  /* ==========================================================
     POSITION
     ========================================================== */

  const reposition = () => {
    if (!video.isConnected || !host.isConnected) {
      return;
    }

    const rect = video.getBoundingClientRect();

    if (!rect.width || !rect.height) {
      host.style.display = "none";

      return;
    }

    host.style.display = "block";

    /*
     * 229px button.
     * Right side of video.
     * -10 means the button is slightly above
     * the top edge of the video.
     */

    const left = Math.max(4, rect.right - 229);

    const top = Math.max(4, rect.top - 10);

    host.style.left = `${left}px`;

    host.style.top = `${top}px`;
  };

  /* ==========================================================
     VIDEO EVENTS
     ========================================================== */

  video.addEventListener("play", reposition, true);

  video.addEventListener("loadedmetadata", reposition, true);

  video.addEventListener("loadeddata", reposition, true);

  video.addEventListener("durationchange", reposition, true);

  /* ==========================================================
     WINDOW EVENTS
     ========================================================== */

  window.addEventListener("resize", reposition, {
    passive: true,
  });

  window.addEventListener("scroll", reposition, {
    passive: true,
  });

  /* ==========================================================
     FULLSCREEN
     ========================================================== */

  document.addEventListener(
    "fullscreenchange",
    () => {
      try {
        if (
          document.fullscreenElement &&
          host.parentElement !== document.fullscreenElement
        ) {
          document.fullscreenElement.appendChild(host);
        } else if (
          !document.fullscreenElement &&
          host.parentElement !== document.body
        ) {
          document.body.appendChild(host);
        }
      } catch (_) {}

      reposition();
    },
    true,
  );

  /* ==========================================================
     SAVE PANEL
     ========================================================== */

  videoPanels.set(video, {
    host,
    shadow,
    wrap,
    button,
    popup,
    reposition,
  });

  /* ==========================================================
     INITIAL POSITION
     ========================================================== */

  reposition();

  wrap.classList.remove("visible");

  /* ==========================================================
     YOUTUBE PREFETCH
     ========================================================== */

  if (isYouTubePage()) {
    const payload = videoDownloadPayload(video);

    if (payload?.url) {
      prefetchVideoOptions(payload);
    }
  }
}

/* ============================================================
   VIDEO SCANNER
   ============================================================ */

function scanVideos(root = document) {
  try {
    if (isVideoElement(root)) {
      createVideoPanel(root);
    }

    const videos = root.querySelectorAll?.("video") || [];

    for (const video of videos) {
      createVideoPanel(video);
    }
  } catch (_) {}
}

/* ============================================================
   INITIAL SCAN
   ============================================================ */

scanVideos(document);

/* ============================================================
   MUTATION OBSERVER
   ============================================================ */

const videoObserver = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes || []) {
      if (node.nodeType === 1) {
        scanVideos(node);
      }
    }
  }
});

videoObserver.observe(document.documentElement || document, {
  childList: true,
  subtree: true,
});

/* ============================================================
   TARGET URL MESSAGE
   ============================================================ */

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "idm:get-target-url") {
    return;
  }

  const url = targetUrl(lastTarget);

  if (!url) return;

  chrome.runtime
    .sendMessage({
      type: "idm:target-url",

      url,

      fileName: fileNameFromTarget(lastTarget),

      referrer: message.referrer || location.href,
    })
    .catch(() => {});
});
