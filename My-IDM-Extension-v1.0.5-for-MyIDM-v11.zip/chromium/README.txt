My IDM Extension 1.0.5 (for My IDM desktop v11)

Compatible with the localhost bridge in My IDM v11
(token: idm-browser-bridge-v25-7f4d92b3, ports 45873-45883).

What this build fixes vs stock 1.0.1:
- VS Code /thank-you intermediate pages no longer steal the arm and leave .exe to Chrome
- page-hook MAIN-world signals are relayed to the background worker
- Every HTTP link click arms the tab (real DownloadItem still decides)
- Windows / Mac / Linux / Export style buttons are detected
- Longer arm + gesture windows (45s) for multi-step download flows
- Real file downloads after any recent user gesture are captured

Install:
1. Make sure My IDM desktop app (v11) is running.
2. Open chrome://extensions
3. Enable Developer mode.
4. Remove any old "My IDM Extension".
5. Load unpacked → select this chromium folder.
6. Refresh the website, then click the download button.

If Chrome still downloads the file:
- Open chrome://extensions → My IDM → Service worker → check errors
- Confirm desktop app is running and bridge log shows a port 45873-45883
