const BRIDGE_TOKEN = "idm-browser-bridge-v25-7f4d92b3";
const BRIDGE_PORTS = Array.from({ length: 11 }, (_, i) => 45873 + i);
const ARM_WINDOW_MS = 45000;
const DOWNLOAD_DEDUPE_MS = 2500;

let armedTabId = null;
let armedAt = 0;
let armedMode = "";
const sentForTab = new Set();
const requestHeadersByTab = new Map();
// Keep the captured browser headers keyed by the exact network URL as well.
// This is important for authenticated downloads (such as ChatGPT file URLs),
// where another request in the same tab can otherwise overwrite the Cookie.
const requestHeadersByUrl = new Map();
const capturedRequestByTab = new Set();
const recentForwarded = new Map();
const pendingPageRequests = new Map();
const mediaCandidatesByTab = new Map();
const recentUserGestureByTab = new Map();
const startupTabs = new Map();
const startupWindows = new Map();
const TAB_STARTUP_GRACE_MS = 20000;
const USER_GESTURE_GRACE_MS = 45000;
const STARTUP_SESSION_GRACE_MS = 15000;
// A Chrome profile can be opened after the extension service worker has already
// started. In that case runtime.onStartup does not fire again. Treat each newly
// created browser window as a short startup window too, while still allowing
// an explicit user gesture to trigger IDM immediately.
const NEW_WINDOW_STARTUP_GRACE_MS = 15000;
// Global quiet period after any profile/window open. Session-restore downloads
// (often with tabId = -1) must never open the IDM popup during this window.
const PROFILE_QUIET_MS = 20000;
// Never use an old page/network request to resolve a later blob/data download.
// This short TTL is long enough for a real JS-generated download, but prevents
// a previous download URL from leaking into a newly opened profile/tab.
const DOWNLOAD_FALLBACK_TTL_MS = 5000;
let startupSessionUntil = 0;
let profileQuietUntil = 0;
const MAX_MEDIA_CANDIDATES = 24;

function beginProfileQuiet(ms = PROFILE_QUIET_MS) {
  const until = Date.now() + ms;
  if (until > profileQuietUntil) profileQuietUntil = until;
  if (until > startupSessionUntil) startupSessionUntil = until;
}

function isProfileQuiet() {
  return Date.now() <= profileQuietUntil;
}

function hasAnyRecentUserGesture() {
  const now = Date.now();
  for (const at of recentUserGestureByTab.values()) {
    if (now - Number(at || 0) <= USER_GESTURE_GRACE_MS) return true;
  }
  return false;
}

function isHttpUrl(url) {
  return typeof url === "string" && /^https?:/i.test(url);
}

function cleanFileName(value) {
  if (!value) return "";
  const text = String(value).replace(/\\/g, "/");
  const name = text.split("/").pop() || "";
  return name.replace(/[<>:"/\\|?*\u0000-\u001F]/g, "_").trim();
}

function looksLikeDownloadUrl(url) {
  if (!isHttpUrl(url)) return false;
  try {
    const u = new URL(url);
    const s = `${u.pathname} ${u.search}`.toLowerCase();
    return (
      /\.(exe|msi|zip|7z|rar|tar|gz|bz2|xz|pdf|dmg|pkg|deb|rpm|apk|aab|ipa|iso|img|bin|msix|msixbundle|mp3|wav|flac|aac|ogg|m4a|mp4|mkv|webm|mov|avi|m4v|ts|m3u8|mpd|csv|tsv|xlsx|xls|docx|doc|pptx|ppt|txt|rtf|json|xml)(?:$|[?#])/.test(
        u.pathname.toLowerCase(),
      ) ||
      /(?:^|[?&])(?:download|attachment|filename|file|fileName|file_name)=/i.test(
        s,
      )
    );
  } catch (_) {
    return false;
  }
}

function arm(tabId, mode = "dynamic") {
  armedTabId = typeof tabId === "number" ? tabId : null;
  armedAt = Date.now();
  armedMode = mode;
  if (typeof armedTabId === "number") {
    sentForTab.delete(armedTabId);
    requestHeadersByTab.delete(armedTabId);
    capturedRequestByTab.delete(armedTabId);
  }
}

function disarm(tabId = armedTabId) {
  if (typeof tabId === "number") {
    sentForTab.delete(tabId);
    requestHeadersByTab.delete(tabId);
    capturedRequestByTab.delete(tabId);
  }
  armedTabId = null;
  armedAt = 0;
  armedMode = "";
}

function isArmed(tabId) {
  return (
    Date.now() - armedAt <= ARM_WINDOW_MS &&
    (armedTabId === null || tabId === armedTabId)
  );
}

async function sendToIdm(payload) {
  if (!isHttpUrl(payload?.url)) return false;
  const body = {
    url: payload.url,
    finalUrl: payload.finalUrl || payload.url,
    fileName: cleanFileName(payload.fileName || ""),
    contentType: payload.contentType || "",
    referrer: payload.referrer || "",
    headers:
      payload.headers && typeof payload.headers === "object"
        ? payload.headers
        : {},
    youtubeFormat:
      typeof payload.youtubeFormat === "string" ? payload.youtubeFormat : "",
    youtubeAudioOnly: Boolean(payload.youtubeAudioOnly),
    ytdlp: Boolean(payload.ytdlp),
    mediaUrl: isHttpUrl(payload.mediaUrl) ? payload.mediaUrl : "",
  };
  for (const port of BRIDGE_PORTS) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/add`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-IDM-Bridge-Token": BRIDGE_TOKEN,
        },
        body: JSON.stringify(body),
        cache: "no-store",
      });
      if (response.ok) return true;
    } catch (_) {}
  }
  return false;
}

async function getVideoOptions(payload) {
  const body = {
    url: payload?.url || "",
    title: payload?.title || "Video",
  };
  for (const port of BRIDGE_PORTS) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/youtube-info`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-IDM-Bridge-Token": BRIDGE_TOKEN,
        },
        body: JSON.stringify(body),
        cache: "no-store",
      });
      if (response.ok) return await response.json();
    } catch (_) {}
  }
  return { success: false, error: "Desktop manager is not running" };
}

async function sendOnce(payload, tabId = null) {
  if (!isHttpUrl(payload?.url)) return false;
  const urlKey = String(payload.url);
  const now = Date.now();
  const previous = recentForwarded.get(urlKey);
  if (previous && now - previous < DOWNLOAD_DEDUPE_MS) return true;
  recentForwarded.set(urlKey, now);
  for (const [key, stamp] of recentForwarded) {
    if (now - stamp > 15000) recentForwarded.delete(key);
  }
  const key = typeof tabId === "number" ? tabId : -1;
  sentForTab.add(key);
  const ok = await sendToIdm(payload);
  if (!ok) {
    recentForwarded.delete(urlKey);
    sentForTab.delete(key);
  }
  return ok;
}

function isLikelyMediaUrl(url) {
  if (!isHttpUrl(url)) return false;
  const value = String(url).toLowerCase();
  return (
    /\.(?:mp4|webm|mov|m4v|mkv|m3u8|mpd|m4s|ts)(?:[?#]|$)/i.test(value) ||
    /(?:videoplayback|video|media|manifest|playlist|stream|seg(?:ment)?|\.fbcdn\.net|cdninstagram\.com|tiktokcdn|twimg\.com|v\.redd\.it)/i.test(
      value,
    )
  );
}

function rememberMediaCandidate(tabId, url, headers = {}, contentType = "") {
  if (typeof tabId !== "number" || !isHttpUrl(url)) return;
  if (
    !isLikelyMediaUrl(url) &&
    !/^video\//i.test(contentType) &&
    !/mpegurl|dash\+xml/i.test(contentType)
  )
    return;
  const list = mediaCandidatesByTab.get(tabId) || [];
  const key = String(url);
  const existing = list.find((item) => item.url === key);
  const item = {
    url: key,
    headers: headers && typeof headers === "object" ? headers : {},
    contentType: contentType || existing?.contentType || "",
    at: Date.now(),
  };
  const next = [item, ...list.filter((x) => x.url !== key)].slice(
    0,
    MAX_MEDIA_CANDIDATES,
  );
  mediaCandidatesByTab.set(tabId, next);
}

function getMediaCandidates(tabId) {
  if (typeof tabId !== "number") return [];
  const list = mediaCandidatesByTab.get(tabId) || [];
  const fresh = list.filter(
    (item) => Date.now() - Number(item.at || 0) < 120000,
  );
  mediaCandidatesByTab.set(tabId, fresh);
  return fresh;
}

function scoreMediaCandidate(item) {
  const url = String(item?.url || "");
  const type = String(item?.contentType || "").toLowerCase();
  let score = 0;
  if (/mpegurl|dash\+xml/i.test(type)) score += 100;
  if (/\.m3u8(?:[?#]|$)/i.test(url)) score += 95;
  if (/\.mpd(?:[?#]|$)/i.test(url)) score += 90;
  if (/video\//i.test(type)) score += 80;
  if (/\.mp4(?:[?#]|$)/i.test(url)) score += 75;
  if (/\.webm(?:[?#]|$)/i.test(url)) score += 70;
  if (/\.m4s|\.ts(?:[?#]|$)/i.test(url)) score += 30;
  if (/segment|frag|chunk|range/i.test(url)) score -= 35;
  return score;
}

function selectMediaCandidates(tabId) {
  return getMediaCandidates(tabId)
    .sort((a, b) => scoreMediaCandidate(b) - scoreMediaCandidate(a))
    .slice(0, 12);
}

function createMenus() {
  try {
    chrome.contextMenus.removeAll(() => {
      if (chrome.runtime.lastError) {
        console.debug(
          "IDM context menu reset:",
          chrome.runtime.lastError.message,
        );
      }

      try {
        chrome.contextMenus.create(
          {
            id: "idm-download",
            title: "Download with My IDM",
            contexts: ["link", "page", "image", "audio", "video"],
          },
          () => {
            if (chrome.runtime.lastError) {
              console.debug(
                "IDM context menu create:",
                chrome.runtime.lastError.message,
              );
            }
          },
        );
      } catch (error) {
        console.debug("IDM context menu error:", error);
      }
    });
  } catch (error) {
    console.debug("IDM context menu setup error:", error);
  }
}

chrome.runtime.onInstalled.addListener(createMenus);
async function markStartupTabs() {
  const now = Date.now();
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs || []) {
      if (typeof tab.id === "number") startupTabs.set(tab.id, { at: now });
    }
  } catch (_) {}
}

function markStartupTab(tabId) {
  if (typeof tabId !== "number") return;
  if (Date.now() <= startupSessionUntil) {
    startupTabs.set(tabId, { at: Date.now() });
  }
}

function clearTabDownloadState(tabId) {
  if (typeof tabId !== "number") return;
  pendingPageRequests.delete(tabId);
  requestHeadersByTab.delete(tabId);
  capturedRequestByTab.delete(tabId);
  sentForTab.delete(tabId);
  recentUserGestureByTab.delete(tabId);
  armedTabId === tabId && disarm(tabId);
}

function markWindowStartup(windowId) {
  if (typeof windowId === "number") startupWindows.set(windowId, Date.now());
}

function isWindowStartup(windowId) {
  if (typeof windowId !== "number") return false;
  const at = startupWindows.get(windowId) || 0;
  if (!at) return false;
  if (Date.now() - at <= NEW_WINDOW_STARTUP_GRACE_MS) return true;
  startupWindows.delete(windowId);
  return false;
}

chrome.runtime.onStartup.addListener(async () => {
  createMenus();
  // Chrome restores tabs/windows asynchronously. Keep a quiet period so
  // session-restore / interrupted downloads never open the IDM popup.
  beginProfileQuiet(PROFILE_QUIET_MS);
  await markStartupTabs();
  for (const delay of [250, 1000, 2500, 5000, 10000]) {
    setTimeout(() => {
      if (isProfileQuiet()) void markStartupTabs();
    }, delay);
  }
});

chrome.windows.onCreated.addListener((window) => {
  // Opening another Chrome profile does not fire runtime.onStartup again.
  // Treat the whole profile open as quiet — not only this window's tabs.
  beginProfileQuiet(PROFILE_QUIET_MS);
  markWindowStartup(window?.id);
  void chrome.tabs
    .query({ windowId: window.id })
    .then((tabs) => {
      for (const tab of tabs || []) {
        clearTabDownloadState(tab.id);
        startupTabs.set(tab.id, { at: Date.now() });
      }
    })
    .catch(() => {});
});

chrome.tabs.onCreated.addListener((tab) => {
  clearTabDownloadState(tab?.id);
  // Tabs created while a profile/window is still settling stay in startup mode.
  if (isProfileQuiet() || Date.now() <= startupSessionUntil) {
    markStartupTab(tab?.id);
  } else {
    markStartupTab(tab?.id);
  }
});

createMenus();

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "idm-download") return;
  const tabId = tab?.id;
  const direct = info.linkUrl || info.srcUrl;

  if (isHttpUrl(direct)) {
    await sendOnce(
      {
        url: direct,
        finalUrl: direct,
        referrer: info.pageUrl || info.frameUrl || "",
      },
      null,
    );
    return;
  }

  if (typeof tabId === "number") {
    arm(tabId, "context-dynamic");
    chrome.tabs
      .sendMessage(tabId, {
        type: "idm:get-target-url",
        referrer: info.pageUrl || info.frameUrl || "",
      })
      .catch(() => {});
    setTimeout(() => {
      if (isArmed(tabId)) disarm(tabId);
    }, ARM_WINDOW_MS + 500);
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender.tab?.id;
  if (message?.type === "idm:user-gesture") {
    if (typeof tabId === "number")
      recentUserGestureByTab.set(tabId, Date.now());
    return;
  }
  if (message?.type === "idm:arm-dynamic-click") {
    if (typeof tabId !== "number") return;
    arm(tabId, message.mode || "left-click-dynamic");
    return;
  }
  if (message?.type === "idm:target-url" && isHttpUrl(message.url)) {
    if (!isArmed(tabId)) return;
    void sendOnce(
      {
        url: message.url,
        finalUrl: message.url,
        fileName: cleanFileName(message.fileName || ""),
        contentType: message.contentType || "",
        referrer: message.referrer || "",
        headers: message.headers || {},
      },
      tabId,
    ).then(() => disarm(tabId));
    return;
  }
  if (message?.type === "idm:click-url" && isHttpUrl(message.url)) {
    void sendOnce(
      {
        url: message.url,
        finalUrl: message.url,
        fileName: cleanFileName(message.fileName || ""),
        referrer: message.referrer || "",
        headers: message.headers || {},
      },
      null,
    );
  }
  if (message?.type === "idm:page-request" && isHttpUrl(message.url)) {
    if (typeof tabId !== "number") return;
    pendingPageRequests.set(tabId, {
      url: message.url,
      fileName: cleanFileName(message.fileName || ""),
      referrer: message.referrer || "",
      at: Date.now(),
    });
    // A page-side fetch/XHR/download anchor is evidence that the user action
    // reached a real network resource. Keep the tab armed so downloads.onCreated
    // can cancel the browser download and hand the same URL to IDM.
    arm(tabId, "page-network");
    return;
  }
  if (message?.type === "idm:page-download" && isHttpUrl(message.url)) {
    if (typeof tabId !== "number") return;
    // Always arm + record gesture so a later real DownloadItem is captured.
    arm(tabId, "page-download");
    recentUserGestureByTab.set(tabId, Date.now());

    // Only forward immediately when the URL is a direct file.
    // Intermediate pages (VS Code /thank-you?dv=win, etc.) must NOT be sent —
    // sending them would disarm the tab and leave the real .exe to Chrome.
    const isDirect =
      message.direct === true ||
      looksLikeDownloadUrl(message.url) ||
      !!cleanFileName(message.fileName || "");

    if (isDirect) {
      void sendOnce(
        {
          url: message.url,
          finalUrl: message.url,
          fileName: cleanFileName(message.fileName || ""),
          referrer: message.referrer || "",
          headers: message.headers || {},
        },
        tabId,
      ).then(() => disarm(tabId));
    }
    return;
  }
  if (message?.type === "idm:video-candidates") {
    const candidates = selectMediaCandidates(tabId);
    try {
      sender.tab?.id != null &&
        chrome.tabs.sendMessage(sender.tab.id, {
          type: "idm:video-candidates-result",
          requestId: message.requestId || "",
          candidates,
        });
    } catch (_) {}
    return;
  }
  if (message?.type === "idm:video-options" && isHttpUrl(message.url)) {
    getVideoOptions(message).then((info) => {
      try {
        sender.tab?.id != null &&
          chrome.tabs.sendMessage(sender.tab.id, {
            type: "idm:video-options-result",
            requestId: message.requestId,
            info,
          });
      } catch (_) {}
    });
    return;
  }
  if (message?.type === "idm:video-download" && isHttpUrl(message.url)) {
    (async () => {
      const ok = await sendToIdm({
        url: message.url,
        finalUrl: message.url,
        fileName: cleanFileName(message.fileName || ""),
        contentType: message.contentType || "",
        referrer: message.referrer || message.pageUrl || "",
        headers:
          message.headers &&
          typeof message.headers === "object" &&
          Object.keys(message.headers).length
            ? message.headers
            : requestHeadersByUrl.get(message.mediaUrl || message.url) ||
              requestHeadersByUrl.get(message.url) ||
              {},
        youtubeFormat: message.youtubeFormat || "",
        youtubeAudioOnly: Boolean(message.youtubeAudioOnly),
        ytdlp: Boolean(message.ytdlp),
        mediaUrl: message.mediaUrl || "",
      });
      try {
        sender.tab?.id != null &&
          chrome.tabs.sendMessage(sender.tab.id, {
            type: "idm:video-download-result",
            requestId: message.requestId || "",
            success: ok,
            error: ok ? "" : "IDM desktop manager is not running",
          });
      } catch (_) {}
    })();
    return;
  }
});

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (!isHttpUrl(details.url)) return;
    const headers = {};
    for (const item of details.requestHeaders || []) {
      const name = String(item.name || "").toLowerCase();
      if (
        [
          "cookie",
          "referer",
          "user-agent",
          "accept",
          "accept-language",
        ].includes(name)
      ) {
        headers[name] = String(item.value || "");
      }
    }
    if (Object.keys(headers).length) {
      const info = { url: details.url, headers, at: Date.now() };
      requestHeadersByTab.set(details.tabId, info);
      requestHeadersByUrl.set(details.url, info);

      // Prevent the map from growing if a page generates many requests.
      const now = Date.now();
      for (const [key, value] of requestHeadersByUrl) {
        if (now - Number(value?.at || 0) > 30000)
          requestHeadersByUrl.delete(key);
      }
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders", "extraHeaders"],
);

// Manifest V3: this extension only observes request headers.
// Do not register a no-op onBeforeRequest listener here. It adds no useful
// interception and has caused compatibility/runtime errors in some Chromium
// builds. Actual browser DownloadItems are handled below.

// Observe media/network requests without blocking them. This is the key
// layer for modern social sites that use MediaSource, HLS, DASH, blob URLs,
// or CDN URLs that never appear as video.src.
try {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      if (details.tabId < 0 || !isHttpUrl(details.url)) return;
      const type = String(details.type || "").toLowerCase();
      if (["media", "xmlhttprequest", "fetch"].includes(type)) {
        rememberMediaCandidate(
          details.tabId,
          details.url,
          requestHeadersByUrl.get(details.url)?.headers || {},
        );
      }
    },
    { urls: ["<all_urls>"] },
  );

  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      if (details.tabId < 0 || !isHttpUrl(details.url)) return;
      const type = String(details.type || "").toLowerCase();
      const contentType =
        (details.responseHeaders || []).find(
          (item) => String(item.name || "").toLowerCase() === "content-type",
        )?.value || "";
      if (
        ["media", "xmlhttprequest", "fetch"].includes(type) ||
        /^video\//i.test(contentType) ||
        /mpegurl|dash\+xml/i.test(contentType)
      ) {
        rememberMediaCandidate(
          details.tabId,
          details.url,
          requestHeadersByUrl.get(details.url)?.headers || {},
          contentType,
        );
      }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders", "extraHeaders"],
  );
} catch (error) {
  console.debug("IDM media observer unavailable:", error);
}

// Intercept real browser downloads → send to IDM and cancel Chrome's copy.
// Must NOT treat profile open / session restore as a user download.
chrome.downloads.onCreated.addListener(async (item) => {
  if (!item) return;

  const tabId = typeof item.tabId === "number" ? item.tabId : -1;
  const validTab = tabId >= 0;
  let finalUrl = item.finalUrl || item.url;
  const now = Date.now();

  for (const [windowId, startedAt] of startupWindows) {
    if (now - startedAt > NEW_WINDOW_STARTUP_GRACE_MS)
      startupWindows.delete(windowId);
  }

  const startup = validTab ? startupTabs.get(tabId) : null;
  const windowStartup =
    typeof item.windowId === "number" && isWindowStartup(item.windowId);
  const gestureAt = validTab ? recentUserGestureByTab.get(tabId) || 0 : 0;
  const hasRecentGesture = now - gestureAt <= USER_GESTURE_GRACE_MS;
  const armedForTab = validTab && isArmed(tabId);
  const anyGesture = hasRecentGesture || hasAnyRecentUserGesture();

  // Prefer same-tab gesture/arm. Also accept a real file-looking download when
  // there was any recent user gesture in the browser (covers redirect chains
  // and thank-you pages where tabId / arm may not line up perfectly).
  const looksFile = looksLikeDownloadUrl(finalUrl);
  const userInitiatedForThisTab = hasRecentGesture || armedForTab;
  const userInitiatedFile =
    looksFile && (userInitiatedForThisTab || anyGesture);

  // ── Suppress automatic / profile-open downloads ──────────────────────────
  // Chrome often recreates interrupted downloads on profile open with
  // tabId = -1 (no tab). Those must never open the IDM popup.
  if (!userInitiatedForThisTab && !userInitiatedFile) {
    return;
  }

  // Global quiet period after profile/window open.
  if (isProfileQuiet() && !userInitiatedForThisTab && !userInitiatedFile) {
    return;
  }

  // Per-tab / per-window startup grace (restored pages, new profile windows).
  if (
    ((startup && now - startup.at <= TAB_STARTUP_GRACE_MS) || windowStartup) &&
    !userInitiatedForThisTab &&
    !userInitiatedFile
  ) {
    return;
  }

  if (startup && now - startup.at > TAB_STARTUP_GRACE_MS) {
    startupTabs.delete(tabId);
  }

  // Blob/data-style browser downloads do not expose an HTTP URL in DownloadItem.
  // Reuse the most recent page-side network URL from THIS tab only.
  if (!isHttpUrl(finalUrl) && validTab) {
    const pending = pendingPageRequests.get(tabId);
    const requestInfo = requestHeadersByTab.get(tabId);
    const pendingFresh =
      pending && now - Number(pending.at || 0) <= DOWNLOAD_FALLBACK_TTL_MS;
    const requestFresh =
      requestInfo &&
      now - Number(requestInfo.at || 0) <= DOWNLOAD_FALLBACK_TTL_MS;

    if (pendingFresh) {
      finalUrl = pending.url;
    } else if (requestFresh) {
      finalUrl = requestInfo.url;
    } else {
      finalUrl = "";
    }
  }
  if (!isHttpUrl(finalUrl)) return;

  // Real DownloadItem after user action (or armed click path): hand off to IDM.
  const exactRequest = requestHeadersByUrl.get(finalUrl);
  const tabRequest = validTab ? requestHeadersByTab.get(tabId) : null;
  const freshTabRequest =
    tabRequest && now - Number(tabRequest.at || 0) <= DOWNLOAD_FALLBACK_TTL_MS
      ? tabRequest
      : null;
  const requestInfo = exactRequest || freshTabRequest;
  const pending = validTab ? pendingPageRequests.get(tabId) : null;
  const freshPending =
    pending && now - Number(pending.at || 0) <= DOWNLOAD_FALLBACK_TTL_MS
      ? pending
      : null;
  const payload = {
    url: finalUrl,
    finalUrl,
    fileName: cleanFileName(item.filename || freshPending?.fileName || ""),
    referrer: requestInfo?.headers?.referer || freshPending?.referrer || "",
    headers: requestInfo?.headers || {},
  };

  // Send to IDM first. Only cancel Chrome's download if the bridge accepted it.
  const ok = await sendOnce(payload, validTab ? tabId : null);

  if (ok) {
    try {
      await chrome.downloads.cancel(item.id);
    } catch (_) {}
  }

  requestHeadersByUrl.delete(finalUrl);

  if (validTab) {
    pendingPageRequests.delete(tabId);
    if (isArmed(tabId)) disarm(tabId);
  }

  if (!ok) {
    console.debug(
      "IDM Bridge: desktop manager unavailable; browser download left untouched",
    );
  }
});

chrome.tabs.onUpdated.addListener((tabId) => {
  // Do not clear the startup marker at "complete". Automatic downloads can
  // start immediately after page load. The marker expires by time instead.
  const startup = startupTabs.get(tabId);
  if (startup && Date.now() - startup.at > TAB_STARTUP_GRACE_MS) {
    startupTabs.delete(tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  disarm(tabId);
  mediaCandidatesByTab.delete(tabId);
  startupTabs.delete(tabId);
  recentUserGestureByTab.delete(tabId);
  if (removeInfo?.isWindowClosing) startupWindows.delete(removeInfo.windowId);
});

chrome.action.onClicked.addListener(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url && isHttpUrl(tab.url)) {
    await sendOnce(
      { url: tab.url, finalUrl: tab.url, referrer: tab.url },
      null,
    );
  }
});
